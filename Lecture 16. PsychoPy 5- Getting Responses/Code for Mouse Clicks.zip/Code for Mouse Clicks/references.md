#references for mouse clicks

http://stackoverflow.com/questions/23112750/single-mouse-click-within-while-loop-psychopy?rq=1