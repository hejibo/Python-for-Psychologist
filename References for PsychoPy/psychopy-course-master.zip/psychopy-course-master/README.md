# psychopy-course
The course materials for using [psychopy](https://github.com/psychopy/psychopy) for psychophysics and neuroscience. See the [course homepage at lindeloev.net](http://lindeloev.net/?page_id=134) for the full course.

The main "products" of the course is [ppc.py](ppc.py) and [template.py](ppc_template.py).

All scripts that have an "import ppc" assumes that ppc.py is in the same directory as that script.
