__author__ = 'hejibo'

s=0
for i in range(2,101,2):
    s = s+i
print s