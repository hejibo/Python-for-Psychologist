__author__ = 'hejibo'
'''
- show all the even numbers from 1 to 20.

- show all the odd numbers from 1 to 20.

'''

for i in range(2,22,2):
    print i

print '----------------------------'

for odd in range(1,20,2):
    print odd
