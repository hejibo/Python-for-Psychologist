__author__ = 'hejibo'

n = 5
while n>0:
    print n
    n  = n +1


print 'Finished'
print '^-^ Yeah!~'