__author__ = 'hejibo'

ntimes = 10
while ntimes>0:
    print "Hello Python"
    ntimes=ntimes-1

print 'Finished'
print '^-^ Yeah!~'
