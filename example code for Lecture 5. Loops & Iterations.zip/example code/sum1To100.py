__author__ = 'hejibo'
s=0
for i in range(1,101):
    s=s+i
print s

print '----------------------------'
print 'summation of all the odd numbers from 1 to 100'
s=0
for i in range(1,101,2):
    s=s+i
print s
