__author__ = 'hejibo'

maxSalary = 0

SalaryList =[10000,70000,60000,50000,88888]

for salary in SalaryList:
    if salary>maxSalary:
        maxSalary=salary

print maxSalary