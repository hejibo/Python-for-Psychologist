__author__ = 'hejibo'

for value in [1,2,3,4]:
    print value

print '----------------------------'
aSet = ['Jibo He',"Jasmine", "Bill Gates","I am not Bill"]
for name in aSet:
    print name

print '----------------------------'
for i in range(10):
    print i
