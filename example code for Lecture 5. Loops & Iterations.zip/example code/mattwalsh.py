__author__ = 'hejibo'

print "Hello World\n" * 10